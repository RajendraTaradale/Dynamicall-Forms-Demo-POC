import { LoaderDirective } from './loader.directive';

describe('LoaderDirective', () => {
  it('should create an instance', () => {
    const directive = new LoaderDirective();
    expect(directive).toBeTruthy();
  });
});
