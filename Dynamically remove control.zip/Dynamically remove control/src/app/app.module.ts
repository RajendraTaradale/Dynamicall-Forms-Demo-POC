import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { DynamicControlComponent } from './dynamic-control/dynamic-control.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonloaderComponent } from './commonloader/commonloader.component';
import { LoaderDirective } from './loader.directive';
@NgModule({
  declarations: [
    AppComponent,
    DynamicControlComponent,
    CommonloaderComponent,
    LoaderDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule, FormsModule, ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
